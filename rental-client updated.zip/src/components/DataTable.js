import React from 'react'

const DataTable = () => {
    return (
        <div>DataTable</div>
    )
}

export default DataTable