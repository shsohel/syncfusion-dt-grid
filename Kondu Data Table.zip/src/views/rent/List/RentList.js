import React from 'react';

const RentList = () => {
  return <div>Hello</div>;
};

export default RentList;
