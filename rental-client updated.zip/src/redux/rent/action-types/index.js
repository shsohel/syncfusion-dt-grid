export const GET_RENTS = 'GET_RENTS';
export const GET_RENTS_BY_QUERY = 'GET_RENTS_BY_QUERY';
export const GET_RENT_BY_ID = 'GET_RENT_BY_ID';
export const ADD_RENT = 'ADD_RENT';
export const UPDATE_RENT = 'UPDATE_RENT';
export const DELETE_RENT = 'DELETE_RENT';
